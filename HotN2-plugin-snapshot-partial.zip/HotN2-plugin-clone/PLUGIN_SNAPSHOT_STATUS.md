# HotN2 — cópia parcial via GitHub

Origem: `jogosdriveparreiras-a11y/HotN2`, branch `main`, commit `6c972f245d538cf58ffaba87957ebdf0a4113155`.

Os 83 arquivos presentes foram comparados aos hashes Git retornados pelo GitHub e conferem. O plugin não devolveu bytes para estes seis arquivos binários; eles foram omitidos para evitar arquivos vazios no lugar dos originais:

- `Amanda NPCs/1777174290544.png` — 1.740.704 bytes
- `Magnus_FeixeArcano.png` — 7.342.684 bytes
- `Sombria_Esfaquear.png` — 1.206.700 bytes
- `en_soldier.png` — 1.111.197 bytes
- `hero_magnus_full.png` — 6.815.905 bytes
- `hero_ranger.png` — 1.343.351 bytes

Esta pasta não é um clone Git completo e o projeto Godot não abrirá corretamente sem esses arquivos. O plugin permite buscar o conteúdo de arquivos e devolver texto ou Base64, mas sua resposta fica vazia para esses arquivos binários maiores. Ele não disponibiliza uma operação `git clone` ou download de arquivo compactado do repositório.
