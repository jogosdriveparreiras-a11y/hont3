extends Node2D

enum State { INIT, SELECTING, PLACING, BATTLE_PLAYER, BATTLE_ENEMY, END }
var current_state = State.INIT

# --- DADOS DE RPG ---
var hero_classes = [
	{"name": "Fighter", "hp": 30, "max_hp": 30, "dmg": 8, "spd": 5, "color": Color.FIREBRICK},
	{"name": "Wizard",  "hp": 15, "max_hp": 15, "dmg": 12,"spd": 4, "color": Color.ROYAL_BLUE},
	{"name": "Rogue",   "hp": 20, "max_hp": 20, "dmg": 10,"spd": 8, "color": Color.FOREST_GREEN},
	{"name": "Cleric",  "hp": 25, "max_hp": 25, "dmg": 6, "spd": 3, "color": Color.GOLD},
	{"name": "Ranger",  "hp": 22, "max_hp": 22, "dmg": 9, "spd": 7, "color": Color.DARK_GREEN},
	{"name": "Paladin", "hp": 35, "max_hp": 35, "dmg": 7, "spd": 2, "color": Color.WHITE_SMOKE}
]

var enemy_types = [
	{"name": "Goblin",   "hp": 10, "dmg": 3, "spd": 6, "color": Color.WEB_GREEN},
	{"name": "Orc",      "hp": 25, "dmg": 7, "spd": 3, "color": Color.DARK_OLIVE_GREEN},
	{"name": "Skeleton", "hp": 15, "dmg": 5, "spd": 5, "color": Color.LIGHT_GRAY},
	{"name": "Troll",    "hp": 40, "dmg": 10,"spd": 1, "color": Color.SADDLE_BROWN}
]

var available_classes = []
var allies = []
var enemies = []

# --- VARIÁVEIS DE SISTEMA ---
var placing_class = null
var placing_is_front = true

# NÓS DINÂMICOS
var bg_rect: ColorRect
var bgm_player: AudioStreamPlayer
var entities_layer: Node2D
var ui_layer: CanvasLayer
var class_panel: Panel
var msg_label: Label
var ghost_rect: ColorRect

signal enemy_clicked(target)

func _ready():
	randomize()
	available_classes = hero_classes.duplicate(true)
	build_scene_tree()
	setup_enemies()
	start_character_selection()

# ==========================================
# 1. CONSTRUÇÃO DA CENA (VIA CÓDIGO)
# ==========================================
func build_scene_tree():
	# Fundo da Batalha
	bg_rect = ColorRect.new()
	bg_rect.size = Vector2(1152, 648)
	bg_rect.color = Color(0.15, 0.15, 0.2) # Pode trocar por um TextureRect depois
	add_child(bg_rect)
	
	# Música de Fundo (BGM)
	bgm_player = AudioStreamPlayer.new()
	# bgm_player.stream = load("res://sua_musica.mp3") # Descomente quando tiver a música
	add_child(bgm_player)
	bgm_player.play()
	
	# Camada onde ficam os sprites (aliados e inimigos)
	entities_layer = Node2D.new()
	add_child(entities_layer)
	
	# Fantasma do posicionamento
	ghost_rect = ColorRect.new()
	ghost_rect.size = Vector2(80, 120)
	ghost_rect.hide()
	add_child(ghost_rect)
	
	# Interface (UI)
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)
	
	msg_label = Label.new()
	msg_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.add_theme_font_size_override("font_size", 32)
	msg_label.text = "Prepare-se para a batalha!"
	ui_layer.add_child(msg_label)
	
	class_panel = Panel.new()
	class_panel.size = Vector2(600, 400)
	class_panel.position = Vector2((1152-600)/2, (648-400)/2)
	ui_layer.add_child(class_panel)

# ==========================================
# 2. SETUP E SELEÇÃO DE PERSONAGENS
# ==========================================
func setup_enemies():
	var front_count = randi() % 3 + 1 # 1 a 3 inimigos na frente
	for i in range(4):
		var e_base = enemy_types[randi() % enemy_types.size()]
		var enemy = e_base.duplicate(true)
		enemy["max_hp"] = enemy["hp"]
		enemy["is_front"] = (i < front_count)
		enemies.append(enemy)

func start_character_selection():
	if allies.size() >= 4:
		start_battle()
		return
		
	current_state = State.SELECTING
	msg_label.text = "Escolha um herói (%d/4)" % (allies.size() + 1)
	class_panel.show()
	
	# Limpar botões antigos
	for child in class_panel.get_children():
		child.queue_free()
		
	var y_offset = 20
	for cls in available_classes:
		var btn = Button.new()
		btn.text = "%s (HP:%d, Dano:%d, Vel:%d)" % [cls.name, cls.hp, cls.dmg, cls.spd]
		btn.size = Vector2(560, 40)
		btn.position = Vector2(20, y_offset)
		# Conecta o botão passando a classe como argumento
		btn.pressed.connect(_on_class_chosen.bind(cls))
		class_panel.add_child(btn)
		y_offset += 50

func _on_class_chosen(cls):
	class_panel.hide()
	placing_class = cls
	placing_is_front = true
	current_state = State.PLACING
	msg_label.text = "Posicione seu herói (Setas ou Mouse para mudar a linha. ENTER para confirmar)"
	render_entities() # Renderiza para vermos os inimigos e aliados já colocados

func _process(_delta):
	if current_state == State.PLACING:
		# Lógica do Fantasma Piscando
		var time = Time.get_ticks_msec()
		ghost_rect.visible = (time / 200) % 2 == 0
		ghost_rect.color = placing_class.color
		
		# Mouse hover para trocar as linhas
		var mouse_x = get_global_mouse_position().x
		if mouse_x > 0 and mouse_x < 225: placing_is_front = false
		elif mouse_x >= 225 and mouse_x < 500: placing_is_front = true
		
		# Setas para trocar as linhas
		if Input.is_action_just_pressed("ui_left"): placing_is_front = false
		if Input.is_action_just_pressed("ui_right"): placing_is_front = true
		
		# Atualiza a posição X do fantasma na tela (Linha frente = 300, Trás = 150)
		var target_x = 300 if placing_is_front else 150
		ghost_rect.position = Vector2(target_x - 40, 324 - 60) # Centralizado verticalmente
		
		# Confirmação
		if Input.is_action_just_pressed("ui_accept"):
			confirm_placement()

func confirm_placement():
	ghost_rect.hide()
	placing_class["is_front"] = placing_is_front
	allies.append(placing_class)
	available_classes.erase(placing_class)
	placing_class = null
	render_entities()
	start_character_selection()

# ==========================================
# 3. RENDERIZAÇÃO AUTOMÁTICA E REDISTRIBUIÇÃO
# ==========================================
func render_entities(highlight_entity = null):
	for c in entities_layer.get_children():
		c.queue_free()
		
	var p_front = []; var p_back = []
	var e_front = []; var e_back = []
	
	for a in allies:
		if a.hp > 0: (p_front if a.is_front else p_back).append(a)
	for e in enemies:
		if e.hp > 0: (e_front if e.is_front else e_back).append(e)
		
	# Desenha as 4 linhas com as posições X fixas
	draw_group(p_back, 150, false, highlight_entity)
	draw_group(p_front, 300, false, highlight_entity)
	draw_group(e_front, 850, true, highlight_entity)
	draw_group(e_back, 1000, true, highlight_entity)

func draw_group(group: Array, x_pos: float, is_enemy: bool, highlight = null):
	var count = group.size()
	if count == 0: return
	
	var spacing = 150
	var start_y = 324 - ((count - 1) * spacing) / 2.0
	
	for i in range(count):
		var entity = group[i]
		var y_pos = start_y + (i * spacing)
		
		var rect = ColorRect.new()
		rect.size = Vector2(80, 120)
		rect.position = Vector2(x_pos - 40, y_pos - 60)
		rect.color = entity.color
		
		# Borda amarela se for o turno dele
		if highlight != null and entity == highlight:
			var border = ColorRect.new()
			border.size = rect.size + Vector2(10, 10)
			border.position = Vector2(-5, -5)
			border.color = Color.YELLOW
			rect.add_child(border)
			border.move_to_bottom() # Põe a borda por trás do sprite
		
		# Textos
		var lbl = Label.new()
		lbl.text = "%s\nHP: %d\nVel: %d" % [entity.name, entity.hp, entity.spd]
		lbl.position = Vector2(0, -50)
		lbl.add_theme_color_override("font_color", Color.WHITE)
		lbl.add_theme_color_override("font_outline_color", Color.BLACK)
		lbl.add_theme_constant_override("outline_size", 4)
		rect.add_child(lbl)
		
		# Se for inimigo, criar um botão invisível por cima para podermos clicar nele e atacar
		if is_enemy:
			var btn = Button.new()
			btn.size = rect.size
			btn.modulate = Color(1, 1, 1, 0) # Transparente
			btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
			btn.pressed.connect(_on_enemy_clicked.bind(entity))
			rect.add_child(btn)
			
		entities_layer.add_child(rect)

func _on_enemy_clicked(enemy):
	if current_state == State.BATTLE_PLAYER:
		enemy_clicked.emit(enemy)

# ==========================================
# 4. LÓGICA DE BATALHA
# ==========================================
func sort_by_speed(a, b):
	if a.spd != b.spd:
		return a.spd > b.spd
	return randf() > 0.5 # Desempate aleatório

func start_battle():
	class_panel.hide()
	msg_label.text = "BATALHA INICIADA!"
	await get_tree().create_timer(1.5).timeout
	battle_loop()

func battle_loop():
	while current_state != State.END:
		await player_phase()
		if current_state == State.END: break
		await enemy_phase()

func player_phase():
	current_state = State.BATTLE_PLAYER
	var sorted_allies = allies.filter(func(a): return a.hp > 0)
	sorted_allies.sort_custom(sort_by_speed)
	
	for ally in sorted_allies:
		if ally.hp <= 0: continue
		if get_live_enemies().size() == 0:
			end_game("VENCEU")
			return
			
		render_entities(ally)
		msg_label.text = "Turno de " + ally.name + ". Clique em um inimigo para atacar!"
		
		# Pausa a execução da função até o jogador clicar num inimigo
		var target = await self.enemy_clicked 
		
		msg_label.text = "%s ataca %s causando %d de dano!" % [ally.name, target.name, ally.dmg]
		target.hp -= ally.dmg
		render_entities(ally) # Atualiza a barra de HP
		
		await get_tree().create_timer(1.2).timeout
		
		if target.hp <= 0:
			msg_label.text = "%s foi derrotado!" % target.name
			await get_tree().create_timer(1.0).timeout
			render_entities()

func enemy_phase():
	current_state = State.BATTLE_ENEMY
	var sorted_enemies = enemies.filter(func(e): return e.hp > 0)
	sorted_enemies.sort_custom(sort_by_speed)
	
	for enemy in sorted_enemies:
		if enemy.hp <= 0: continue
		var live_allies = allies.filter(func(a): return a.hp > 0)
		if live_allies.size() == 0:
			end_game("GAME OVER")
			return
			
		render_entities(enemy)
		var target = live_allies[randi() % live_allies.size()] # Alvo aleatório
		
		msg_label.text = "Inimigo %s ataca %s causando %d de dano!" % [enemy.name, target.name, enemy.dmg]
		target.hp -= enemy.dmg
		render_entities(enemy)
		
		await get_tree().create_timer(1.5).timeout

func get_live_enemies():
	return enemies.filter(func(e): return e.hp > 0)

func end_game(result_text):
	current_state = State.END
	render_entities() # Remove as bordas amarelas
	msg_label.text = ""
	
	var end_label = Label.new()
	end_label.text = result_text
	end_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	end_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	end_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	end_label.add_theme_font_size_override("font_size", 100)
	
	# Muda a cor baseado se venceu ou perdeu
	if result_text == "VENCEU":
		end_label.add_theme_color_override("font_color", Color.GREEN)
	else:
		end_label.add_theme_color_override("font_color", Color.RED)
		
	ui_layer.add_child(end_label)