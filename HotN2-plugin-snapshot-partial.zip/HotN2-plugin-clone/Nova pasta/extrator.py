import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk

class ExtratorSprite:
    def __init__(self, root):
        self.root = root
        self.root.title("Extrator de Sprite Sheet 1x4 - Pro")
        self.root.geometry("900x600")
        
        # Variáveis de Estado
        self.caminho_imagem = None
        self.imagem_original = None
        self.tk_imagem = None
        
        self.largura_celula = 0
        self.altura_celula = 0
        self.celulas_selecionadas = []
        
        self.cor_transparente = None
        self.capturando_cor = False

        # Variáveis da Interface
        self.var_modo = tk.StringVar(value="lincol") # 'lincol' ou 'pixel'
        self.var_linhas = tk.StringVar(value="1")
        self.var_colunas = tk.StringVar(value="4")
        self.var_largura_px = tk.StringVar(value="32")
        self.var_altura_px = tk.StringVar(value="32")
        
        # Rastreia mudanças nos campos de texto para atualizar em tempo real
        for var in [self.var_modo, self.var_linhas, self.var_colunas, self.var_largura_px, self.var_altura_px]:
            var.trace_add("write", self.atualizar_tela)

        self.montar_interface()

    def montar_interface(self):
        # --- PAINEL DIREITO (Controles) ---
        painel = tk.Frame(self.root, width=250, padx=10, pady=10)
        painel.pack(side=tk.RIGHT, fill=tk.Y)

        tk.Button(painel, text="📁 Novo Sprite Sheet", command=self.carregar_imagem, bg="#e0e0e0").pack(fill=tk.X, pady=(0, 15))

        tk.Label(painel, text="Modo de Divisão:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        tk.Radiobutton(painel, text="Por Linhas/Colunas", variable=self.var_modo, value="lincol").pack(anchor=tk.W)
        
        frame_lincol = tk.Frame(painel)
        frame_lincol.pack(fill=tk.X, padx=15, pady=2)
        tk.Label(frame_lincol, text="Linhas:").grid(row=0, column=0, sticky=tk.W)
        tk.Entry(frame_lincol, textvariable=self.var_linhas, width=8).grid(row=0, column=1)
        tk.Label(frame_lincol, text="Colunas:").grid(row=1, column=0, sticky=tk.W)
        tk.Entry(frame_lincol, textvariable=self.var_colunas, width=8).grid(row=1, column=1)

        tk.Radiobutton(painel, text="Por Pixel", variable=self.var_modo, value="pixel").pack(anchor=tk.W, pady=(10, 0))
        
        frame_px = tk.Frame(painel)
        frame_px.pack(fill=tk.X, padx=15, pady=2)
        tk.Label(frame_px, text="Largura (px):").grid(row=0, column=0, sticky=tk.W)
        tk.Entry(frame_px, textvariable=self.var_largura_px, width=8).grid(row=0, column=1)
        tk.Label(frame_px, text="Altura (px):").grid(row=1, column=0, sticky=tk.W)
        tk.Entry(frame_px, textvariable=self.var_altura_px, width=8).grid(row=1, column=1)

        tk.Frame(painel, height=2, bd=1, relief=tk.SUNKEN).pack(fill=tk.X, pady=15)

        tk.Label(painel, text="Transparência:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        self.btn_cor = tk.Button(painel, text="Pipeta (Clique na Imagem)", command=self.ativar_captura_cor)
        self.btn_cor.pack(fill=tk.X, pady=5)
        self.lbl_cor = tk.Label(painel, text="Cor: Nenhuma", bg="white", relief=tk.RIDGE)
        self.lbl_cor.pack(fill=tk.X)

        tk.Frame(painel, height=2, bd=1, relief=tk.SUNKEN).pack(fill=tk.X, pady=15)

        self.btn_finalizar = tk.Button(painel, text="✅ Finalizar e Salvar", command=self.salvar_novo_sprite, state=tk.DISABLED, bg="#d4edda")
        self.btn_finalizar.pack(fill=tk.X, side=tk.BOTTOM, pady=10)

        # --- ÁREA ESQUERDA (Imagem com Scroll) ---
        area_canvas = tk.Frame(self.root, bg="gray")
        area_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Adicionando scrollbars para imagens grandes
        scroll_y = tk.Scrollbar(area_canvas, orient=tk.VERTICAL)
        scroll_x = tk.Scrollbar(area_canvas, orient=tk.HORIZONTAL)
        
        self.canvas = tk.Canvas(area_canvas, bg="gray", yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        
        scroll_y.config(command=self.canvas.yview)
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        scroll_x.config(command=self.canvas.xview)
        scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas.bind("<Button-1>", self.ao_clicar)

    def carregar_imagem(self):
        caminho = filedialog.askopenfilename(filetypes=[("Imagens", "*.png *.jpg *.jpeg *.bmp")])
        if not caminho: return

        self.caminho_imagem = caminho
        self.imagem_original = Image.open(self.caminho_imagem).convert("RGBA")
        self.celulas_selecionadas.clear()
        self.cor_transparente = None
        self.lbl_cor.config(text="Cor: Nenhuma", bg="white")
        self.atualizar_tela()

    def atualizar_tela(self, *args):
        if not self.imagem_original: return

        self.canvas.delete("all")
        
        # Desenha a imagem base
        self.tk_imagem = ImageTk.PhotoImage(self.imagem_original)
        img_w, img_h = self.imagem_original.size
        self.canvas.config(scrollregion=(0, 0, img_w, img_h))
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.tk_imagem)

        # Tenta calcular as células, se der erro (ex: campo vazio), aborta o desenho da malha
        try:
            if self.var_modo.get() == "lincol":
                linhas = int(self.var_linhas.get())
                colunas = int(self.var_colunas.get())
                if linhas <= 0 or colunas <= 0: raise ValueError
                self.largura_celula = img_w / colunas
                self.altura_celula = img_h / linhas
            else:
                self.largura_celula = int(self.var_largura_px.get())
                self.altura_celula = int(self.var_altura_px.get())
                if self.largura_celula <= 0 or self.altura_celula <= 0: raise ValueError
        except ValueError:
            return # Se o usuário apagar o número, não crasha, apenas não desenha a malha

        # Desenha Malha
        x = self.largura_celula
        while x < img_w:
            self.canvas.create_line(x, 0, x, img_h, fill="#ff00ff", dash=(4, 4))
            x += self.largura_celula
            
        y = self.altura_celula
        while y < img_h:
            self.canvas.create_line(0, y, img_w, y, fill="#ff00ff", dash=(4, 4))
            y += self.altura_celula

        # Desenha Seleções
        for i, (row, col) in enumerate(self.celulas_selecionadas):
            cx = (col * self.largura_celula) + (self.largura_celula / 2)
            cy = (row * self.altura_celula) + (self.altura_celula / 2)
            self.canvas.create_oval(cx-15, cy-15, cx+15, cy+15, fill="blue", outline="white")
            self.canvas.create_text(cx, cy, text=str(i+1), fill="white", font=("Arial", 14, "bold"))

        # Atualiza o botão de finalizar
        if len(self.celulas_selecionadas) == 4:
            self.btn_finalizar.config(state=tk.NORMAL)
        else:
            self.btn_finalizar.config(state=tk.DISABLED)

    def ativar_captura_cor(self):
        if not self.imagem_original: return
        self.capturando_cor = True
        self.canvas.config(cursor="cross")

    def ao_clicar(self, event):
        if not self.imagem_original: return

        # Ajusta as coordenadas com base no scroll
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)

        # Se estiver no modo de capturar cor transparente
        if self.capturando_cor:
            if 0 <= x < self.imagem_original.width and 0 <= y < self.imagem_original.height:
                r, g, b, *a = self.imagem_original.getpixel((int(x), int(y)))
                self.cor_transparente = (r, g, b)
                hex_cor = f"#{r:02x}{g:02x}{b:02x}"
                self.lbl_cor.config(text=f"Cor: {hex_cor}", bg=hex_cor)
            
            self.capturando_cor = False
            self.canvas.config(cursor="arrow")
            return

        # Impede calcular clique se a malha estiver quebrada (campos vazios)
        if self.largura_celula <= 0 or self.altura_celula <= 0: return

        col = int(x // self.largura_celula)
        row = int(y // self.altura_celula)

        celula = (row, col)

        # Lógica de marcar/desmarcar
        if celula in self.celulas_selecionadas:
            self.celulas_selecionadas.remove(celula) # Desmarca
        else:
            if len(self.celulas_selecionadas) < 4:
                self.celulas_selecionadas.append(celula) # Marca
                
        self.atualizar_tela()

    def salvar_novo_sprite(self):
        nova_img = Image.new("RGBA", (int(self.largura_celula * 4), int(self.altura_celula)))

        # Extrai os frames
        for i, (row, col) in enumerate(self.celulas_selecionadas):
            esq = col * self.largura_celula
            topo = row * self.altura_celula
            dir = esq + self.largura_celula
            baixo = topo + self.altura_celula

            frame = self.imagem_original.crop((esq, topo, dir, baixo))
            nova_img.paste(frame, (int(i * self.largura_celula), 0))

        # Aplica transparência se uma cor foi escolhida
        if self.cor_transparente:
            dados = nova_img.getdata()
            novos_dados = []
            for pixel in dados:
                # Compara o RGB do pixel com a cor escolhida (ignora Alpha atual)
                if pixel[:3] == self.cor_transparente:
                    novos_dados.append((255, 255, 255, 0)) # Fica totalmente transparente
                else:
                    novos_dados.append(pixel)
            nova_img.putdata(novos_dados)

        caminho_salvar = filedialog.asksaveasfilename(
            title="Salvar Novo Sprite Sheet",
            defaultextension=".png",
            filetypes=[("PNG", "*.png")]
        )

        if caminho_salvar:
            nova_img.save(caminho_salvar)
            messagebox.showinfo("Sucesso", "Sprite sheet salvo! Você pode continuar editando ou carregar um novo.")
            self.celulas_selecionadas.clear()
            self.atualizar_tela()

if __name__ == "__main__":
    root = tk.Tk()
    app = ExtratorSprite(root)
    root.mainloop()