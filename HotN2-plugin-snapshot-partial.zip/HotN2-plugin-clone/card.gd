extends Button

@onready var fundo: TextureRect = $Fundo # Mudamos para TextureRect!
@onready var titulo: Label = $Titulo
@onready var nome: Label = $Nome
@onready var tipo: Label = $Tipo
@onready var dano: Label = $Dano
@onready var descricao: RichTextLabel = $Descricao

func setup(card_data, db_data, owner_unit):
	set_meta("card_ref", card_data)
	
	titulo.text = card_data.name
	nome.text = owner_unit.name
	
	# --- 1. LÓGICA DA IMAGEM DO FUNDO ---
	var img_path = "res://" + owner_unit.name + "_" + card_data.name.replace(" ", "") + ".png"
	
	if ResourceLoader.exists(img_path):
		fundo.texture = load(img_path)
	else:
		var full_art = owner_unit.sprite.replace(".png", "_full.png")
		if ResourceLoader.exists(full_art):
			fundo.texture = load(full_art)
		else:
			# Extrai apenas o frame 0 do spritesheet para o fundo da carta
			var sheet = load(owner_unit.sprite)
			var atlas = AtlasTexture.new()
			atlas.atlas = sheet
			var frame_w = sheet.get_width() / 9.0
			var frame_h = sheet.get_height() / 6.0
			atlas.region = Rect2(0, 0, frame_w, frame_h)
			
			fundo.texture = atlas
			
	fundo.modulate = Color.WHITE

	# --- 2. LÓGICA DE DADOS (Dano, Tipo e Descrição) ---
	var card_type_str = "Outro"
	var dmg_val_str = "--"
	var desc_text = ""
	
	if db_data.get("alcance", false):
		desc_text += "🏹 Alcance\n"
		
	# Lê os efeitos para descobrir o tipo e o dano final
	for effect in db_data.effects:
		if effect.tag == "DAMAGE":
			card_type_str = effect.get("type", "IMPACTO").capitalize()
			
			var stat_val = owner_unit.get("imp", 0) if effect.type == "IMPACTO" else owner_unit.get("pod", 0)
			var total_dmg = stat_val + effect.get("base_dmg", 0)
			dmg_val_str = str(total_dmg)
			
			if effect.get("combo", 0) > 0:
				desc_text += "Hit extra: " + str(effect.combo) + " alvos\n"
			if effect.get("penetrante", false):
				desc_text += "Penetrante (Ignora Escudos)\n"
				
		elif effect.tag == "HEAL":
			card_type_str = "Cura"
			desc_text += "Recupera " + str(effect.amount) + " de Vida\n"
			
		elif effect.tag == "BUFF":
			card_type_str = "Suporte"
			desc_text += "Aplica " + effect.get("status", "").capitalize() + " por " + str(effect.get("duration", 1)) + " turnos\n"

	tipo.text = card_type_str
	dano.text = dmg_val_str
	
	# Adiciona o texto customizado do banco de dados (se houver)
	var custom_desc = db_data.get("desc", "")
	if custom_desc != "":
		desc_text += "\n" + custom_desc
		
	var ap_init_text = "\n[AP: %d | Init: %d⚡]" % [db_data.cost_ap, db_data.init_mod]
	descricao.text = desc_text + ap_init_text

func set_blocked(is_blocked):
	if is_blocked:
		fundo.modulate = Color(0.3, 0.3, 0.3) # Escurece a imagem
		descricao.text += "\n\n[color=red][BLOQUEADA][/color]" # RichTextLabel aceita cores assim!
	else:
		fundo.modulate = Color.WHITE
		
var glow_panel: Panel
var time_passed = 0.0
var is_hovering = false

func _ready():
	# Criamos o painel de brilho elétrico via código para não sujar sua cena
	glow_panel = Panel.new()
	glow_panel.show_behind_parent = true
	# Faz ele ser um pouco maior que a carta
	glow_panel.size = size + Vector2(30, 30)
	glow_panel.position = Vector2(-15, -15)
	glow_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color.TRANSPARENT
	sb.border_width_left = 6; sb.border_width_top = 6
	sb.border_width_right = 6; sb.border_width_bottom = 6
	sb.border_color = Color(0.2, 0.8, 1.0, 1.0) # Azul Elétrico Claro
	sb.shadow_color = Color(0.0, 0.5, 1.0, 0.8) # Sombra Azul Escura
	sb.shadow_size = 30
	sb.set_corner_radius_all(15) # Arredonda as pontas
	
	glow_panel.add_theme_stylebox_override("panel", sb)
	glow_panel.hide()
	add_child(glow_panel)

func set_hover_glow(active: bool):
	is_hovering = active
	glow_panel.visible = active

func _process(delta):
	# Anima o "pulso" da eletricidade mudando a opacidade da borda
	if is_hovering and glow_panel.visible:
		time_passed += delta
		var pulse = 0.5 + (sin(time_passed * 15.0) * 0.5) # Vibra rápido
		var sb = glow_panel.get_theme_stylebox("panel") as StyleBoxFlat
		if sb:
			sb.border_color.a = pulse
			sb.shadow_color.a = pulse * 0.8
