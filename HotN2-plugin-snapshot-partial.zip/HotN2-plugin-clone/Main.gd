extends Node2D

enum State { INIT, SELECTING, PLACING, BATTLE_PLAYER, BATTLE_ENEMY, END }
var current_state = State.INIT

# ==========================================
# 1. BANCO DE DADOS (DATA-DRIVEN DESIGN)
# ==========================================
const SPRITE_HEIGHT = 300.0
const ANIM = { "IDLE": 0, "SWING": 12, "THRUST": 3, "DAMAGE": 36, "VICTORY": 15, "DEAD": 53 }

# Matriz de Vantagens (Atacante na Linha, Defensor na Coluna)
const TYPE_CHART = {
	"BRUTO":       {"BRUTO": 1.0, "TECNICO": 1.0, "PSICOLOGICO": 1.0, "MENTAL": 1.25, "PROJETIVO": 0.75, "QUIMICO": 1.0},
	"TECNICO":     {"BRUTO": 1.0, "TECNICO": 1.0, "PSICOLOGICO": 1.25, "MENTAL": 1.0, "PROJETIVO": 1.0, "QUIMICO": 0.75},
	"PSICOLOGICO": {"BRUTO": 0.75, "TECNICO": 1.0, "PSICOLOGICO": 1.0, "MENTAL": 1.0, "PROJETIVO": 1.0, "QUIMICO": 1.25},
	"MENTAL":      {"BRUTO": 1.0, "TECNICO": 0.75, "PSICOLOGICO": 1.0, "MENTAL": 1.0, "PROJETIVO": 1.25, "QUIMICO": 1.0},
	"PROJETIVO":   {"BRUTO": 1.0, "TECNICO": 1.25, "PSICOLOGICO": 0.75, "MENTAL": 1.0, "PROJETIVO": 1.0, "QUIMICO": 1.0},
	"QUIMICO":     {"BRUTO": 1.25, "TECNICO": 1.0, "PSICOLOGICO": 1.0, "MENTAL": 0.75, "PROJETIVO": 1.0, "QUIMICO": 1.0}
}

# Escolha seu favorito apagando os outros!
const TYPE_ICONS = {
	"BRUTO": "🥊",       # Opções: 🦍, 🔨, 🪨
	"TECNICO": "🥋",     # Opções: 🤺, ⚙️, 🎯
	"PSICOLOGICO": "🎭", # Opções: 👁️, 🗣️, 😵‍💫
	"MENTAL": "🧠",      # Opções: 🔮, 🌌, 🧘
	"PROJETIVO": "💥",   # Opções: ⚡, 🔫, ☄️
	"QUIMICO": "🧪"      # Opções: ☣️, 🟢, 🧬
}

# Banco de Heróis
const HERO_DB = {
	"Guerreiro":   {"hp": 40, "imp": 10, "arm": 4, "pod": 2, "esc": 2, "vel": 5, "sprite": "res://hero_fighter.png", "color": Color.FIREBRICK, "type": "BRUTO", "basic": "Briga", "special": "Placa de Titânio"},
	"Mago":        {"hp": 20, "imp": 2, "arm": 1, "pod": 12, "esc": 6, "vel": 4, "sprite": "res://hero_wizard.png",  "color": Color.ROYAL_BLUE, "type": "PROJETIVO", "basic": "Feixe Arcano", "special": "Explosão Arcana"},
	"Ladino":      {"hp": 25, "imp": 8, "arm": 2, "pod": 4, "esc": 3, "vel": 9, "sprite": "res://hero_rogue.png",   "color": Color.FOREST_GREEN, "type": "TECNICO", "basic": "Briga", "special": "Chuva de Lâminas"},
	"Clerigo":     {"hp": 30, "imp": 5, "arm": 3, "pod": 8, "esc": 5, "vel": 3, "sprite": "res://hero_cleric.png",  "color": Color.GOLD, "type": "MENTAL", "basic": "Feixe Arcano", "special": "Cura Vital"},
	"Patrulheiro": {"hp": 28, "imp": 5, "arm": 3, "pod": 7, "esc": 4, "vel": 7, "sprite": "res://hero_ranger.png",  "color": Color.DARK_GREEN, "type": "QUIMICO", "basic": "Arco e Flecha", "special": "Salto Ágil"},
	"Magnus":      {"hp": 28, "imp": 5, "arm": 3, "pod": 7, "esc": 4, "vel": 7, "sprite": "res://hero_magnus.png",  "color": Color.DARK_GREEN, "type": "QUIMICO", "basic": "Feixe Arcano", "special": "Cura Vital"},
	"Paladino":    {"hp": 45, "imp": 7, "arm": 6, "pod": 6, "esc": 5, "vel": 2, "sprite": "res://hero_paladin.png", "color": Color.WHITE_SMOKE, "type": "PSICOLOGICO", "basic": "Briga", "special": "Aura de Égide"}
}

# Banco de Inimigos
const ENEMY_DB = [
	{"name": "Soldado",  "hp": 15, "imp": 6, "arm": 2, "pod": 1, "esc": 1, "vel": 6, "sprite": "res://en_soldier.png", "color": Color.WEB_GREEN, "type": "BRUTO", "skills": ["Briga", "Placa de Titânio"]},
	{"name": "Elite",    "hp": 30, "imp": 9, "arm": 5, "pod": 2, "esc": 3, "vel": 4, "sprite": "res://en_elite.png",   "color": Color.DARK_RED, "type": "TECNICO", "skills": ["Briga", "Chuva de Lâminas"]},
	{"name": "Cao",      "hp": 20, "imp": 7, "arm": 1, "pod": 1, "esc": 1, "vel": 8, "sprite": "res://en_dog.png",     "color": Color.ORANGE_RED, "type": "QUIMICO", "skills": ["Mordida Feroz"]},
	{"name": "Atirador", "hp": 12, "imp": 2, "arm": 1, "pod": 8, "esc": 2, "vel": 5, "sprite": "res://en_sniper.png",  "color": Color.LIGHT_SKY_BLUE, "type": "PROJETIVO", "skills": ["Arco e Flecha"]},
	{"name": "Cultista", "hp": 18, "imp": 2, "arm": 2, "pod": 9, "esc": 6, "vel": 3, "sprite": "res://en_cultist.png", "color": Color.PURPLE, "type": "MENTAL", "skills": ["Feixe Arcano", "Manto Sombrio"]},
	{"name": "Oficial",  "hp": 25, "imp": 5, "arm": 4, "pod": 4, "esc": 4, "vel": 7, "sprite": "res://en_officer.png", "color": Color.DIM_GRAY, "type": "PSICOLOGICO", "skills": ["Aura de Égide", "Briga"]}
]

# Banco de Cartas
const CARD_DB = {
	"Briga": {
		"cost_ap": 1, "init_mod": 1, "target": "ENEMY", "alcance": false,
		"effects": [{"tag": "DAMAGE", "type": "IMPACTO", "base_dmg": 4}]
	},
	"Arco e Flecha": {
		"cost_ap": 1, "init_mod": 1, "target": "ENEMY", "alcance": true,
		"effects": [{"tag": "DAMAGE", "type": "PODER", "base_dmg": 3}]
	},
	"Feixe Arcano": {
		"cost_ap": 1, "init_mod": 1, "target": "ENEMY", "alcance": true,
		"effects": [{"tag": "DAMAGE", "type": "PODER", "base_dmg": 5}]
	},
	"Chuva de Lâminas": {
		"cost_ap": 2, "init_mod": -1, "target": "ENEMY", "alcance": false,
		"effects": [{"tag": "DAMAGE", "type": "IMPACTO", "base_dmg": 3, "combo": 2}]
	},
	"Explosão Arcana": {
		"cost_ap": 3, "init_mod": -2, "target": "ENEMY_ROW", "alcance": true,
		"effects": [{"tag": "DAMAGE", "type": "PODER", "base_dmg": 8}]
	},
	"Mordida Feroz": {
		"cost_ap": 1, "init_mod": 0, "target": "ENEMY", "alcance": false,
		"effects": [{"tag": "DAMAGE", "type": "IMPACTO", "base_dmg": 2, "combo": 1}]
	},
	# Habilidades de Buff/Cura continuam iguais
	"Placa de Titânio": {"cost_ap": 1, "init_mod": 0, "target": "SELF", "alcance": false, "effects": [{"tag": "BUFF", "status": "armadura", "duration": 2}]},
	"Aura de Égide": {"cost_ap": 2, "init_mod": -1, "target": "SELF", "alcance": false, "effects": [{"tag": "BUFF", "status": "escudo", "duration": 2}, {"tag": "SHIELD"}]},
	"Salto Ágil": {"cost_ap": 1, "init_mod": -1, "target": "SELF", "alcance": false, "effects": [{"tag": "BUFF", "status": "voar", "duration": 2}]},
	"Manto Sombrio": {"cost_ap": 1, "init_mod": 0, "target": "SELF", "alcance": false, "effects": [{"tag": "BUFF", "status": "escudo", "duration": 3}]},
	"Cura Vital": {"cost_ap": 2, "init_mod": -1, "target": "ALLY", "alcance": true, "effects": [{"tag": "HEAL", "amount": 15}]}
}



# ==========================================
# 2. VARIÁVEIS DE SISTEMA
# ==========================================
var allies = []
var enemies = []
var available_classes = []

var deck = []
var hand = []
var discard_pile = []
var pending_card = null 

var placing_unit = null
var placing_is_front = true
var last_mouse_pos = Vector2.ZERO
var is_attacking = false

var entities_layer: Node2D
var ui_layer: CanvasLayer
var msg_label: Label
var class_panel: Panel
var cards_container: Control
# var end_turn_btn: Button
var init_label: Label
var ap_label: Label
var fade_overlay: ColorRect

var camera: Camera2D
var cam_target_pos: Vector2
var cam_target_zoom: Vector2
var shake_strength = 0.0

var left_portrait: TextureRect
var right_portrait: TextureRect

var actions_left = 3
var max_actions = 3
var initiative_points = 1

var audio_manager: Node
var inspect_bg: ColorRect
var inspect_portrait: TextureRect
var inspect_info: Label
var redraws_left = 2
var redraw_label: Label
var holding_card = null
var hold_time = 0.0
var redraw_progress_bar: TextureProgressBar

var deck_pos = Vector2(1100, 600)    # Canto inferior direito
var discard_pos = Vector2(50, 600)   # Canto inferior esquerdo

var card_scene = preload("res://Card.tscn")
var screen_w = ProjectSettings.get_setting("display/window/size/viewport_width")
var screen_h = ProjectSettings.get_setting("display/window/size/viewport_height")
	
	
# --- REFERÊNCIAS DO EDITOR (Arraste os nós para aqui no Inspetor) ---
@export_group("Posicionamento de Combate")
@export var pos_ally_back: Marker2D
@export var pos_ally_front: Marker2D
@export var pos_enemy_front: Marker2D
@export var pos_enemy_back: Marker2D

@export_group("Interface de Usuário (HUD)")
@export var label_ap: Label
@export var label_init: Label
@export var label_redraw: Label
@export var button_end_turn: Button

signal turn_ended

# ==========================================
# 3. SETUP INICIAL
# ==========================================
func _ready():
	for key in HERO_DB.keys():
		var hero_data = HERO_DB[key].duplicate(true)
		hero_data["name"] = key
		available_classes.append(hero_data)
		
	setup_world()
	setup_enemies()
	
	var tween = create_tween()
	tween.tween_property(fade_overlay, "modulate:a", 0.0, 1.5)
	tween.tween_callback(func(): 
		fade_overlay.hide()
		start_character_selection()
	)

func setup_world():
	# Lê a resolução atual configurada no projeto (ex: 1920x1080)
	var screen_w = ProjectSettings.get_setting("display/window/size/viewport_width")
	var screen_h = ProjectSettings.get_setting("display/window/size/viewport_height")
	
	var bg = TextureRect.new()
	bg.texture = load("res://battleback.png")
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.size = Vector2(screen_w + 400, screen_h + 400) # Fica maior que a tela para permitir o "shake" da câmera
	bg.position = Vector2(-200, -200) 
	if bg.texture == null:
		var pr = ColorRect.new()
		pr.size = bg.size; pr.color = Color(0.1, 0.1, 0.12)
		bg.add_child(pr)
	add_child(bg)
	
	var audio = AudioStreamPlayer.new()
	audio.stream = load("res://battle_music.ogg")
	audio.finished.connect(func(): audio.play())
	add_child(audio)
	if audio.stream: audio.play()
	
	entities_layer = Node2D.new()
	add_child(entities_layer)
	
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)
	
	camera = Camera2D.new()
	camera.position = Vector2(screen_w / 2.0, screen_h / 2.0)
	cam_target_pos = camera.position
	cam_target_zoom = Vector2(1, 1)
	add_child(camera)
	
	left_portrait = TextureRect.new()
	left_portrait.size = Vector2(400, 600)
	left_portrait.position = Vector2(0, (screen_h - 600) / 2.0)
	left_portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	left_portrait.hide()
	ui_layer.add_child(left_portrait)
	
	right_portrait = TextureRect.new()
	right_portrait.size = Vector2(400, 600)
	right_portrait.position = Vector2(screen_w - 400, (screen_h - 600) / 2.0)
	right_portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	right_portrait.flip_h = true
	right_portrait.hide()
	ui_layer.add_child(right_portrait)
	
	msg_label = Label.new()
	msg_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.add_theme_font_size_override("font_size", 32)
	ui_layer.add_child(msg_label)
	
	
	class_panel = Panel.new()
	class_panel.size = Vector2(600, 500)
	class_panel.position = (Vector2(screen_w, screen_h) - class_panel.size) / 2.0
	ui_layer.add_child(class_panel)
	
	cards_container = Control.new() 
	cards_container.position = Vector2(screen_w / 2.0, screen_h - 150)
	ui_layer.add_child(cards_container)
	
	deck_pos = Vector2(screen_w - 150, screen_h - 150)
	discard_pos = Vector2(150, screen_h - 150)
	
	fade_overlay = ColorRect.new()
	fade_overlay.size = Vector2(screen_w, screen_h)
	fade_overlay.color = Color.BLACK
	ui_layer.add_child(fade_overlay)
	
	# Em vez de criar o botão, apenas ligamos o sinal do que já existe no editor
	if button_end_turn:
		button_end_turn.pressed.connect(func(): if current_state == State.BATTLE_PLAYER: turn_ended.emit())
		button_end_turn.hide()

	# Certifique-se que o cards_container ainda é criado ou exportado
	if not cards_container:
		cards_container = Control.new()
		ui_layer.add_child(cards_container)
	
	# Ajuste a posição do container de cartas relativa à tela
	screen_w = ProjectSettings.get_setting("display/window/size/viewport_width")
	screen_h = ProjectSettings.get_setting("display/window/size/viewport_height")
	cards_container.position = Vector2(screen_w / 2.0, screen_h - 150)
	
	# --- JANELA DE INSPECIONAR ---
	inspect_bg = ColorRect.new()
	inspect_bg.size = Vector2(screen_w, screen_h)
	inspect_bg.color = Color(0, 0, 0, 0.8)
	inspect_bg.hide()
	
	var close_bg_btn = Button.new()
	close_bg_btn.size = inspect_bg.size
	close_bg_btn.modulate.a = 0
	close_bg_btn.pressed.connect(hide_inspect)
	inspect_bg.add_child(close_bg_btn)
	
	var inspect_panel = Panel.new()
	inspect_panel.size = Vector2(800, 550)
	inspect_panel.position = (Vector2(screen_w, screen_h) - inspect_panel.size) / 2.0
	inspect_bg.add_child(inspect_panel)
	
	inspect_portrait = TextureRect.new()
	inspect_portrait.size = Vector2(350, 600)
	inspect_portrait.position = Vector2(-50, -25)
	inspect_portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	inspect_panel.add_child(inspect_portrait)
	
	inspect_info = Label.new()
	inspect_info.position = Vector2(320, 60)
	inspect_info.add_theme_font_size_override("font_size", 26)
	inspect_panel.add_child(inspect_info)
	
	var close_btn = Button.new()
	close_btn.text = "X"
	close_btn.size = Vector2(60, 60)
	close_btn.position = Vector2(inspect_panel.size.x - 70, 10)
	close_btn.pressed.connect(hide_inspect)
	inspect_panel.add_child(close_btn)
	
	ui_layer.add_child(inspect_bg)
	
	audio_manager = load("res://AudioManager.gd").new()
	add_child(audio_manager)
	
	redraw_progress_bar = TextureProgressBar.new()
	redraw_progress_bar.fill_mode = TextureProgressBar.FILL_CLOCKWISE
	redraw_progress_bar.size = Vector2(60, 60)
	redraw_progress_bar.nine_patch_stretch = true
	redraw_progress_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	redraw_progress_bar.z_index = 100 # <--- AQUI: Garante que fique acima das cartas
	redraw_progress_bar.hide()
	
	var ring_tex = load("res://ring.png")
	if ring_tex:
		redraw_progress_bar.texture_progress = ring_tex
		redraw_progress_bar.tint_progress = Color.YELLOW
	
	ui_layer.add_child(redraw_progress_bar)

func setup_enemies():
	var front_limit = randi_range(1, 3)
	for i in range(4):
		var en = ENEMY_DB[randi() % ENEMY_DB.size()].duplicate(true)
		en["is_front"] = (i < front_limit)
		en["max_hp"] = en["hp"]
		en["statuses"] = {"armadura": 0, "escudo": 0, "voar": 0, "pouso": 0}
		enemies.append(en)

# ==========================================
# 4. SELEÇÃO DE PERSONAGENS E POSICIONAMENTO
# ==========================================
func start_character_selection():
	if allies.size() >= 4:
		start_battle()
		return
	
	current_state = State.SELECTING
	class_panel.show()
	msg_label.text = "Escolha seu herói (%d/4)" % (allies.size() + 1)
	
	for c in class_panel.get_children(): c.queue_free()
	var y = 20
	for cls in available_classes:
		var b = Button.new()
		var type_icon = TYPE_ICONS[cls.type]
		
		# NOVA LINHA: Mostra HP, Impacto, Poder e Velocidade usando as novas chaves
		b.text = "%s %s (HP: %d | 🥊 IMP: %d | 🪄 POD: %d | 👟 VEL: %d)" % [
			type_icon, cls.name, cls.hp, cls.get("imp", 0), cls.get("pod", 0), cls.get("vel", 0)
		]
		
		b.size = Vector2(460, 40)
		b.position = Vector2(20, y)
		b.pressed.connect(_on_class_picked.bind(cls))
		class_panel.add_child(b)
		y += 50

func _on_class_picked(cls):
	audio_manager.play_sfx("res://click.ogg") # Exemplo de SFX
	class_panel.hide()
	placing_unit = cls.duplicate(true)
	placing_unit["is_preview"] = true 
	current_state = State.PLACING
	last_mouse_pos = get_global_mouse_position()

func _input(event):
	# CANCELAR SELEÇÃO DA CARTA (Tecla X ou Clique Direito)
	if current_state == State.BATTLE_PLAYER and pending_card != null:
		var pressed_x = event is InputEventKey and event.pressed and event.keycode == KEY_X
		var pressed_right_click = event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_RIGHT
		
		if pressed_x or pressed_right_click:
			pending_card = null
			msg_label.text = "Seleção cancelada. Inspecione ou escolha outra carta."
			audio_manager.play_sfx("res://click.ogg") # Som opcional
			render_cards()
			render_entities()
			update_focus(null)
			
	# LÓGICA DE POSICIONAMENTO INICIAL (Mantida)
	if current_state == State.PLACING and placing_unit != null:
		if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			confirm_placement()
		elif event.is_action_pressed("ui_accept"):
			confirm_placement()

func confirm_placement():
	audio_manager.play_sfx("res://equip.ogg")
	placing_unit.erase("is_preview")
	placing_unit["max_hp"] = placing_unit.hp
	placing_unit["protection"] = false
	placing_unit["statuses"] = {"armadura": 0, "escudo": 0, "voar": 0, "pouso": 0}
	allies.append(placing_unit)
	
	for i in range(available_classes.size()):
		if available_classes[i].name == placing_unit.name:
			available_classes.remove_at(i)
			break
			
	placing_unit = null
	render_entities()
	start_character_selection()

# ==========================================
# 5. CÂMERA E ANIMAÇÕES (FRAME A FRAME)
# ==========================================
func _process(_delta):
	var delta_time = get_process_delta_time()
	var time = Time.get_ticks_msec()
	
	# --- ANIMAÇÕES (SISTEMA 54 FRAMES) ---
	for container in entities_layer.get_children():
		for child in container.get_children():
			if child is Sprite2D and child.hframes == 9:
				var u = container.get_meta("unit_data")
				var state = u.get("anim_state", ANIM.IDLE)
				if state == ANIM.DEAD:
					child.frame = ANIM.DEAD
				else:
					child.frame = state + (int(time * 0.006) % 3)

	# --- PANNING SUAVE (VISÃO TÁTICA) ---
	if current_state == State.BATTLE_PLAYER and pending_card != null and not is_attacking:
		var screen_center = screen_w / 2.0
		var mouse_x = get_global_mouse_position().x
		var target_offset = (mouse_x - screen_center) * 0.5 
		cam_target_pos = Vector2(screen_center + target_offset, screen_h / 2.0)
		cam_target_zoom = Vector2(1.1, 1.1)

	# --- CÂMERA E SHAKE ---
	if camera != null:
		camera.position = camera.position.lerp(cam_target_pos, 5.0 * delta_time)
		camera.zoom = camera.zoom.lerp(cam_target_zoom, 5.0 * delta_time)
		if shake_strength > 0:
			camera.offset = Vector2(randf_range(-shake_strength, shake_strength), randf_range(-shake_strength, shake_strength))
			shake_strength = lerp(shake_strength, 0.0, 10.0 * delta_time)
		else:
			camera.offset = Vector2.ZERO

	# --- POSICIONAMENTO DE HERÓI ---
	if current_state == State.PLACING and placing_unit != null:
		var input_changed = false
		var current_mouse_pos = get_global_mouse_position()
		
		if Input.is_action_just_pressed("ui_left"):
			placing_is_front = false; input_changed = true
		elif Input.is_action_just_pressed("ui_right"):
			placing_is_front = true; input_changed = true
		elif current_mouse_pos != last_mouse_pos:
			if current_mouse_pos.x < 500:
				var new_front = current_mouse_pos.x > 225
				if placing_is_front != new_front:
					placing_is_front = new_front
					input_changed = true
			last_mouse_pos = current_mouse_pos
		
		if input_changed or placing_unit.get("is_front") == null:
			placing_unit["is_front"] = placing_is_front
			render_entities()
		msg_label.text = "Posicione: " + placing_unit.name + " (Clique para confirmar)"
		
	# --- DENTRO DO _PROCESS (Lógica de Recompra) ---
	if holding_card != null and redraws_left > 0 and current_state == State.BATTLE_PLAYER:
		hold_time += delta_time
		
		if hold_time > 0.5:
			redraw_progress_bar.show()
			# Centralização corrigida para FHD (ajuste os valores se mudar o tamanho do anel)
			redraw_progress_bar.global_position = get_global_mouse_position() - (redraw_progress_bar.size / 2.0)
			redraw_progress_bar.value = ((hold_time - 0.5) / 2.5) * 100
		
		if hold_time >= 3.0:
			var card_to_discard = holding_card
			holding_card = null
			redraw_progress_bar.hide()
			
			# Encontra o nó da carta para animar o voo até o descarte
			for c in cards_container.get_children():
				if c.get_meta("card_ref") == card_to_discard:
					var tween = create_tween().set_parallel(true)
					tween.tween_property(c, "global_position", discard_pos, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN)
					tween.tween_property(c, "scale", Vector2(0.01, 0.01), 0.5)
					tween.tween_property(c, "modulate:a", 0.0, 0.5)
					await tween.finished
					c.queue_free() # Remove o visual
					break
			
			hand.erase(card_to_discard)
			discard_pile.append(card_to_discard)
			redraws_left -= 1
			draw_cards(1)
	
	# --- ANIMAÇÃO DAS BARRAS DE VIDA (BRILHO, TEXTURA E PREVISÃO) ---
	var pulse_alpha = 0.4 + (sin(time * 0.005) * 0.4) # Pulsa de 0.0 a 0.8
	
	for container in entities_layer.get_children():
		if container.has_meta("hp_bar_node"):
			var bar_node = container.get_meta("hp_bar_node")
			var fill_clip = bar_node.get_meta("fill_clip")
			var prev_panel = bar_node.get_meta("prev_panel")
			var tex_rect = bar_node.get_meta("tex_rect")
			var glow_sb = bar_node.get_meta("glow_sb")
			var u = container.get_meta("unit_data")

			var max_hp = u.get("max_hp", u.hp)
			var current_hp = u.hp
			var target_hp = current_hp

			# 1. Pulsação do Brilho Externo
			glow_sb.shadow_color.a = pulse_alpha

			# 2. Rola a textura de listras para a esquerda
			tex_rect.position.x -= 20.0 * delta_time
			if tex_rect.position.x <= -15.0: # Reseta quando passa da largura da textura
				tex_rect.position.x = 0

			# 3. Lógica da Previsão de Dano (Só ativa se o mouse estiver em cima)
			if pending_card != null and container.has_meta("is_hovered") and container.get_meta("is_hovered"):
				var c_data = CARD_DB[pending_card.name]
				var attacker = pending_card.owner
				# Confere se a carta tem efeitos e se o primeiro é de dano
				if c_data.effects.size() > 0 and c_data.effects[0].tag == "DAMAGE":
					var effect = c_data.effects[0]
					var atk_stat = attacker.get("imp", 0) if effect.get("type", "IMPACTO") == "IMPACTO" else attacker.get("pod", 0)
					var def_stat = u.get("arm", 0) if effect.get("type", "IMPACTO") == "IMPACTO" else u.get("esc", 0)
					var raw_dmg = max(0, atk_stat + effect.get("base_dmg", 0) - def_stat)
					var final_dmg = int(float(raw_dmg) * TYPE_CHART[attacker.type][u.type])
					target_hp = max(0, current_hp - final_dmg)

			# 4. Aplica os tamanhos da barra (80.0 é a largura máxima em pixels)
			var bar_width_max = 80.0
			var fill_width = (float(target_hp) / float(max_hp)) * bar_width_max
			var prev_width = (float(current_hp) / float(max_hp)) * bar_width_max

			# O 'lerp' faz a barra amarela descer suavemente
			fill_clip.size.x = fill_width
			prev_panel.size.x = lerp(prev_panel.size.x, prev_width, 15.0 * delta_time)

func update_focus(actor, target = null, zoom_out_override = false):
	if actor == null:
		cam_target_pos = Vector2(screen_w/2.0, screen_h/2.0)
		cam_target_zoom = Vector2(1, 1)
		left_portrait.hide()
		right_portrait.hide()
		return
		
	# --- LÓGICA DO RETRATO ESQUERDO ---
	var tex = load(actor.sprite.replace(".png", "_full.png")) if actor.has("sprite") else null
	if tex:
		left_portrait.texture = tex
		left_portrait.modulate = Color.WHITE
	else:
		# Se não tem full art, recorta o frame 0 do spritesheet
		var sheet = load(actor.sprite)
		var atlas = AtlasTexture.new()
		atlas.atlas = sheet
		var frame_w = sheet.get_width() / 9.0 # Divide pelas 9 colunas
		var frame_h = sheet.get_height() / 6.0 # Divide pelas 6 linhas
		atlas.region = Rect2(0, 0, frame_w, frame_h) # Pega o primeiro quadro (x:0, y:0)
		
		left_portrait.texture = atlas
		left_portrait.modulate = actor.color
	left_portrait.show()
	
	# --- LÓGICA DO RETRATO DIREITO (Se houver alvo) ---
	if target != null:
		# ... (seu código de zoom da câmera continua igual aqui) ...
		
		var t_tex = load(target.sprite.replace(".png", "_full.png")) if target.has("sprite") else null
		if t_tex:
			right_portrait.texture = t_tex
			right_portrait.modulate = Color.WHITE
		else:
			var t_sheet = load(target.sprite)
			var t_atlas = AtlasTexture.new()
			t_atlas.atlas = t_sheet
			var t_frame_w = t_sheet.get_width() / 9.0
			var t_frame_h = t_sheet.get_height() / 6.0
			t_atlas.region = Rect2(0, 0, t_frame_w, t_frame_h)
			
			right_portrait.texture = t_atlas
			right_portrait.modulate = target.color
		right_portrait.show()
	else:
		right_portrait.hide()
		# ... (resto da função de reset da câmera) ...
		if zoom_out_override:
			cam_target_pos = Vector2(screen_w/2.0, screen_h/2.0)
			cam_target_zoom = Vector2(1.0, 1.0)
		else:
			cam_target_pos = actor.get("pos", Vector2(screen_w/2.0, screen_h/2.0))
			cam_target_zoom = Vector2(1.3, 1.3)

# ==========================================
# 6. RENDERIZAÇÃO DE ENTIDADES E ALVOS
# ==========================================
func render_entities(active_unit = null):
	if active_unit == null and pending_card != null:
		active_unit = pending_card.owner

	for n in entities_layer.get_children(): n.queue_free()
	
	var p_back = allies.filter(func(a): return not a.is_front)
	var p_front = allies.filter(func(a): return a.is_front)
	
	if current_state == State.PLACING and placing_unit != null:
		if placing_is_front: p_front.append(placing_unit)
		else: p_back.append(placing_unit)
	
	var e_front = enemies.filter(func(e): return e.is_front and e.hp > 0)
	var e_back = enemies.filter(func(e): return not e.is_front and e.hp > 0)
	
	# Usa a posição X e Y dos marcadores do editor
	draw_row(p_back, pos_ally_back.global_position, false, active_unit)
	draw_row(p_front, pos_ally_front.global_position, false, active_unit)
	draw_row(e_front, pos_enemy_front.global_position, true, active_unit)
	draw_row(e_back, pos_enemy_back.global_position, true, active_unit)
	

func draw_row(units, base_pos: Vector2, is_enemy, active_unit):
	var count = units.size()
	if count == 0: return
	var spacing = 110 # Espaço vertical entre unidades na mesma linha
	
	# O start_y agora é relativo ao Y que você definiu no Marker do editor
	var start_y = base_pos.y - ((count - 1) * spacing) / 2.0
	
	for i in range(count):
		var u = units[i]
		# A posição X vem direto do Marker
		u["pos"] = Vector2(base_pos.x, start_y + (i * spacing))
				
		var container = Node2D.new()
		container.position = u["pos"]
		entities_layer.add_child(container)
		
		u["anim_state"] = ANIM.IDLE if u.hp > 0 else ANIM.DEAD
		container.set_meta("unit_data", u)
		
		var spr = Sprite2D.new()
		var tex = load(u.sprite)
		if tex:
			spr.texture = tex
			spr.flip_h = not is_enemy
			spr.hframes = 9
			spr.vframes = 6
			var s = SPRITE_HEIGHT / (tex.get_size().y / 6.0)
			spr.scale = Vector2(s, s)
		else:
			var img = Image.create(50, 80, false, Image.FORMAT_RGBA8)
			img.fill(u.color)
			spr.texture = ImageTexture.create_from_image(img)
		
		if u.has("is_preview"):
			spr.modulate.a = 0.4 + (sin(Time.get_ticks_msec() * 0.01) * 0.4)
		elif u.hp <= 0:
			spr.modulate = Color(0.3, 0.3, 0.3)
		container.add_child(spr)
		
		# Destaque do Turno (Amarelo)
		if active_unit == u and u.hp > 0:
			var hl_active = ColorRect.new()
			hl_active.size = Vector2(60, 4); hl_active.position = Vector2(-30, 45); hl_active.color = Color.YELLOW
			container.add_child(hl_active)
			var cursor = Label.new()
			cursor.text = "▼"; cursor.position = Vector2(-10, -70); cursor.add_theme_color_override("font_color", Color.YELLOW)
			container.add_child(cursor)

		# --- NOME DO PERSONAGEM E ÍCONE ---
		var name_label = Label.new()
		var type_icon = TYPE_ICONS.get(u.get("type", "BRUTO"), "")
		name_label.text = "%s %s" % [type_icon, u.name]
		if u.get("protection", false): name_label.text += " 🛡️"
		name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		name_label.add_theme_font_size_override("font_size", 14)
		name_label.position = Vector2(-60, 45)
		name_label.size = Vector2(120, 20)
		container.add_child(name_label)
		
		# --- BARRAS DE VIDA CUSTOMIZADAS (100% CONTROLE) ---
		var bar_width = 80.0
		var bar_height = 5.0 # Pode botar até 2 aqui que ela afina!
		var radius = int(bar_height / 2.0) + 1 # Arredonda de acordo com a altura
		
		var bar_node = Control.new()
		bar_node.size = Vector2(bar_width, bar_height)
		bar_node.position = Vector2(-40, 65)
		container.add_child(bar_node)
		container.set_meta("hp_bar_node", bar_node)

		# 1. Fundo Escuro
		var bg = Panel.new()
		bg.size = bar_node.size
		var bg_sb = StyleBoxFlat.new()
		bg_sb.bg_color = Color(0, 0, 0, 0.7)
		bg_sb.set_corner_radius_all(radius)
		bg.add_theme_stylebox_override("panel", bg_sb)
		bar_node.add_child(bg)

		# 2. Brilho Externo (Glow)
		var glow = Panel.new()
		glow.size = bar_node.size
		var glow_sb = StyleBoxFlat.new()
		glow_sb.bg_color = Color.TRANSPARENT
		var base_glow = Color.WEB_GREEN if not is_enemy else Color.CRIMSON
		glow_sb.shadow_color = Color(base_glow.r, base_glow.g, base_glow.b, 0.8)
		glow_sb.shadow_size = 5 # Espessura do brilho externo
		glow_sb.set_corner_radius_all(radius)
		glow.add_theme_stylebox_override("panel", glow_sb)
		bar_node.add_child(glow)
		bar_node.set_meta("glow_sb", glow_sb)

		# 3. Previsão Amarela (Fica por baixo do preenchimento)
		var prev_panel = Panel.new()
		prev_panel.size = Vector2(bar_width, bar_height)
		var prev_sb = StyleBoxFlat.new()
		prev_sb.bg_color = Color.YELLOW
		prev_sb.set_corner_radius_all(radius)
		prev_panel.add_theme_stylebox_override("panel", prev_sb)
		bar_node.add_child(prev_panel)
		bar_node.set_meta("prev_panel", prev_panel)

		# 4. Preenchimento Principal (Clip Mask)
		var fill_clip = Panel.new()
		fill_clip.size = Vector2(bar_width, bar_height)
		fill_clip.clip_children = CanvasItem.CLIP_CHILDREN_ONLY # A mágica acontece aqui
		var clip_sb = StyleBoxFlat.new()
		clip_sb.bg_color = Color.WHITE 
		clip_sb.set_corner_radius_all(radius)
		fill_clip.add_theme_stylebox_override("panel", clip_sb)
		bar_node.add_child(fill_clip)
		bar_node.set_meta("fill_clip", fill_clip)

		# 5. Cor Base (Dentro da máscara)
		var hp_color = ColorRect.new()
		hp_color.size = Vector2(bar_width, bar_height)
		hp_color.color = Color.WEB_GREEN if not is_enemy else Color.CRIMSON
		fill_clip.add_child(hp_color)

		# 6. Textura Animada de Listras (Dentro da máscara)
		var tex_rect = TextureRect.new()
		tex_rect.size = Vector2(bar_width * 2, bar_height) # Mais largo para rolar infinito
		tex_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tex_rect.stretch_mode = TextureRect.STRETCH_TILE
		tex_rect.modulate.a = 0.4 # Transparência da textura
		
		# Geramos uma textura diagonal via código!
		var grad = Gradient.new()
		grad.offsets = [0.0, 0.5, 1.0]
		grad.colors = [Color.TRANSPARENT, Color.WHITE, Color.TRANSPARENT]
		var grad_tex = GradientTexture2D.new()
		grad_tex.gradient = grad
		grad_tex.fill_to = Vector2(1.0, 1.0) # Diagonal
		grad_tex.width = 15
		grad_tex.height = 15
		tex_rect.texture = grad_tex
		
		fill_clip.add_child(tex_rect)
		bar_node.set_meta("tex_rect", tex_rect)
		
		# --- NÚMEROS DE HP (ESCONDIDOS POR PADRÃO) ---
		var hp_numbers = Label.new()
		hp_numbers.text = "%d/%d" % [u.hp, u.get("max_hp", u.hp)]
		hp_numbers.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		hp_numbers.add_theme_font_size_override("font_size", 12)
		hp_numbers.position = Vector2(-40, 75)
		hp_numbers.size = Vector2(80, 20)
		hp_numbers.hide() # Fica invisível no início!
		container.add_child(hp_numbers)
		
		# --- LÓGICA DO BOTÃO DE ALVO INTELIGENTE E INSPEÇÃO ---
		if u.hp > 0 and current_state == State.BATTLE_PLAYER:
			var is_valid_target = false
			var is_inspecting = false
			
			if pending_card != null:
				var c_data = CARD_DB[pending_card.name]
				if c_data.target == "ENEMY" or c_data.target == "ENEMY_ROW": is_valid_target = is_enemy
				elif c_data.target == "ALLY": is_valid_target = not is_enemy
				elif c_data.target == "SELF": is_valid_target = (u == pending_card.owner)
			else:
				# SEM CARTA NA MÃO = TODOS SÃO INSPECIONÁVEIS
				is_valid_target = true
				is_inspecting = true
				
			if is_valid_target:
				var hl_color = Color.WHITE if is_inspecting else Color.RED
				
				var hl_target = ColorRect.new()
				hl_target.size = Vector2(60, 4); hl_target.position = Vector2(-30, 45); hl_target.color = hl_color; hl_target.hide()
				container.add_child(hl_target)
				
				var cursor_target = Label.new()
				cursor_target.text = "▼"; cursor_target.position = Vector2(-10, -70); cursor_target.add_theme_color_override("font_color", hl_color); cursor_target.hide()
				container.add_child(cursor_target)
				
				var btn = Button.new()
				btn.size = Vector2(60, 100); btn.position = Vector2(-30, -50); btn.flat = true
				btn.mouse_entered.connect(func(): 
					hl_target.show(); cursor_target.show()
					hp_numbers.show() 
					container.set_meta("is_hovered", true) # <--- AVISO DE MOUSE EM CIMA
					if not is_inspecting: update_focus(pending_card.owner if pending_card else null, u, false)
				)
				btn.mouse_exited.connect(func(): 
					hl_target.hide(); cursor_target.hide()
					hp_numbers.hide() 
					container.set_meta("is_hovered", false) # <--- AVISO DE MOUSE FORA
					if not is_inspecting: update_focus(pending_card.owner if pending_card else null, null, pending_card != null)
				)
				btn.pressed.connect(func(): _on_target_clicked(u))
				container.add_child(btn)
				
# ==========================================
# 7. GESTÃO DE DECK E CARTAS EM ARCO
# ==========================================
func init_deck():
	deck.clear()
	for a in allies:
		if a.hp <= 0: continue
		
		# 1. Puxa o ataque básico específico do herói (ex: Raio Arcano para o Mago)
		var basic_name = HERO_DB[a.name].get("basic", "Ataque Básico")
		for i in range(3):
			deck.append({"owner": a, "id": randi(), "name": basic_name})
			
		# 2. Puxa a habilidade especial específica do herói
		var special_name = HERO_DB[a.name].special
		deck.append({"owner": a, "id": randi(), "name": special_name})
		
	deck.shuffle()

func draw_cards(amount):
	for i in range(amount):
		if deck.size() == 0:
			if discard_pile.size() == 0: break
			deck = discard_pile.duplicate(); discard_pile.clear(); deck.shuffle()
		
		if deck.size() > 0:
			var card_data = deck.pop_back()
			hand.append(card_data)
			render_cards() # Aqui o render_cards cria o nó
			
			# Pegamos a última carta criada
			var card_node = cards_container.get_child(cards_container.get_child_count() - 1)
			
			# Guardamos o alvo que o render_cards calculou
			var target_pos = card_node.position
			var target_scale = card_node.scale # Pega o 0.16 que definimos
			
			# Iniciamos a animação a partir do deck (pequeno e longe)
			card_node.position = deck_pos - cards_container.position
			card_node.scale = Vector2(0.01, 0.01)
			
			var tween = create_tween().set_parallel(true)
			tween.tween_property(card_node, "position", target_pos, 0.5).set_trans(Tween.TRANS_QUART).set_ease(Tween.EASE_OUT)
			tween.tween_property(card_node, "scale", target_scale, 0.5)
			
			audio_manager.play_sfx("res://card_draw.ogg")
			await get_tree().create_timer(0.1).timeout 

func purge_dead_ally_cards(dead_ally):
	deck = deck.filter(func(c): return c.owner != dead_ally)
	hand = hand.filter(func(c): return c.owner != dead_ally)
	discard_pile = discard_pile.filter(func(c): return c.owner != dead_ally)
	if pending_card != null and pending_card.owner == dead_ally:
		pending_card = null
	render_cards()

func render_cards():
	for c in cards_container.get_children(): c.queue_free()
	label_ap.text = "Ações: %d/%d" % [actions_left, max_actions]
	label_init.text = "Iniciativa: %d/10" % initiative_points
	label_redraw.text = "Recompras: %d/2" % redraws_left
	
	# if redraw_label == null:
	#	redraw_label = Label.new()
	#	redraw_label.position = Vector2(20, 100)
	#	redraw_label.add_theme_font_size_override("font_size", 24)
	#	ui_layer.add_child(redraw_label)
	#redraw_label.text = "Recompras: %d/2" % redraws_left
	
	var hand_size = hand.size()
	for i in range(hand_size):
		var card = hand[i]
		var c_data = CARD_DB[card.name]
		var ratio = 0.5 if hand_size <= 1 else float(i) / (float(hand_size) - 1.0)
		var arc_pos = (ratio * 2.0) - 1.0
		
		# INSTANCIA A SUA CENA VISUAL AQUI!
		var btn = card_scene.instantiate()
		cards_container.add_child(btn)
		
		# Manda os dados para a carta se auto-preencher
		btn.setup(card, c_data, card.owner)
		
		# --- VERIFICAÇÃO DE BLOQUEIO ---
		var in_retaguarda = has_retaguarda(card.owner, allies)
		var is_blocked = false
		if in_retaguarda and not c_data.get("alcance", false): is_blocked = true
		if actions_left < c_data.cost_ap or initiative_points + c_data.init_mod < 0: is_blocked = true
		
		btn.set_blocked(is_blocked)
		
		# --- MATEMÁTICA DE POSIÇÃO E ESCALA RELATIVA ---
		var offset_x = arc_pos * (min(hand_size * 60, 400)) 
		var offset_y = abs(arc_pos) * 25
		var rot = arc_pos * 0.15
		
		btn.pivot_offset = Vector2(732 / 2.0, 1027)
		
		# DEFINA A ESCALA BASE AQUI (Altere este valor e todo o resto obedece!)
		var base_scale_val = 0.20
		var base_scale = Vector2(base_scale_val, base_scale_val)
		var hover_scale = base_scale * 1.50     # 80% maior no Hover
		var selected_scale = base_scale * 2.30  # Gigante quando selecionada
		
		if pending_card == null:
			btn.position = Vector2(offset_x - (732/2.0), offset_y - 1027 + 40)
			btn.rotation = rot
			btn.scale = base_scale
		else:
			if pending_card == card:
				# Carta Selecionada (Centralizada dinamicamente)
				# Como o container está embaixo, mandamos o Y da carta lá pra cima (negativo)
				var tela_y = get_viewport_rect().size.y
				btn.position = Vector2(-(732 / 2.0), -(tela_y / 2.0) - 500) 
				btn.rotation = 0
				btn.scale = selected_scale
				btn.z_index = 50
				btn.set_hover_glow(true) # Mantém o brilho ligado!
			else:
				# Esconde as outras
				btn.position = Vector2(offset_x - (732/2.0), 300) 
				btn.rotation = rot
				btn.scale = base_scale
				
		# --- EVENTOS DE MOUSE UNIFICADOS ---
		btn.mouse_entered.connect(func(): 
			update_focus(card.owner, null, true)
			if pending_card == null and not is_blocked:
				btn.scale = hover_scale # Usa a escala dinâmica correta!
				btn.z_index = 10
				btn.set_hover_glow(true) # Liga a eletricidade
		)
		
		btn.mouse_exited.connect(func(): 
			update_focus(pending_card.owner if pending_card else null, null, pending_card != null)
			if pending_card == null:
				btn.scale = base_scale
				btn.z_index = 0
				btn.set_hover_glow(false) # Desliga a eletricidade
		)
		
		# --- CLIQUES ---
		btn.pressed.connect(func(): 
			if not is_blocked: select_card(card)
			else: audio_manager.play_sfx("res://error.ogg")
		)
		
		btn.button_down.connect(func(): holding_card = card; hold_time = 0.0)
		btn.button_up.connect(func(): holding_card = null; hold_time = 0.0; redraw_progress_bar.hide())
		
func select_card(card):
	if current_state != State.BATTLE_PLAYER: return
	pending_card = card
	audio_manager.play_sfx("res://click.ogg")
	render_cards() 
	render_entities() 
	msg_label.text = "Alvo selecionado para " + card.name + ". Clique no alvo!"
	update_focus(card.owner, null, true)


# ==========================================
# 8. MOTOR DE COMBATE E EFEITOS (DATA-DRIVEN)
# ==========================================
func show_inspect(unit):
	audio_manager.play_sfx("res://click.ogg")
	inspect_bg.show()
	cards_container.hide() # Esconde as cartas para o jogador não clicar nelas
	button_end_turn.hide()
	
	var tex = load(unit.sprite.replace(".png", "_full.png")) if unit.has("sprite") else null
	inspect_portrait.texture = tex if tex else load(unit.sprite)
	inspect_portrait.modulate = unit.color if not tex else Color.WHITE
	
	var type_icon = TYPE_ICONS.get(unit.get("type", "BRUTO"), "")
	var info = "%s %s\n\n" % [type_icon, unit.name]
	info += "❤️ HP: %d / %d\n" % [unit.hp, unit.get("max_hp", unit.hp)]
	info += "🥊 IMP: %d | 🛡️ ARM: %d\n" % [unit.get("imp", 0), unit.get("arm", 0)]
	info += "🪄 POD: %d | 🔮 ESC: %d\n" % [unit.get("pod", 0), unit.get("esc", 0)]
	info += "👟 VEL: %d\n\n" % unit.get("vel", 0)
	info += "🧬 Tipo: %s\n" % unit.get("type", "BRUTO")
	
	if unit.has("special"):
		info += "✨ Especial: %s\n" % unit.special
	
	if unit.has("special"):
		info += "✨ Habilidade Especial:\n %s\n" % unit.special
		
	if unit.get("protection", false):
		info += "\n🛡️ Status: Protegido contra 1 ataque"
		
	inspect_info.text = info

func hide_inspect():
	inspect_bg.hide()
	if current_state == State.BATTLE_PLAYER:
		cards_container.show()
		button_end_turn.show()
		
func start_battle():
	current_state = State.BATTLE_PLAYER
	pending_card = null # Garante que começa vazio
	init_deck()
	draw_cards(5)
	
	button_end_turn.show()
	#ap_label.show()
	#init_label.show()
	
	# ISSO AQUI FAZ A MAGIA DA INSPEÇÃO FUNCIONAR DESDE O SEGUNDO ZERO:
	render_entities() 
	
	battle_loop()

func process_turn_statuses():
	for u in allies + enemies:
		if u.hp <= 0: continue
		if u.statuses.armadura > 0: u.statuses.armadura -= 1
		if u.statuses.escudo > 0: u.statuses.escudo -= 1
		
		# Lógica de Pouso/Voo
		if u.statuses.pouso > 0:
			u.statuses.pouso -= 1
			if u.statuses.pouso > 0: # Volta a voar se sobrou rodadas
				u.statuses.voar = u.statuses.pouso
				u.statuses.pouso = 0
		elif u.statuses.voar > 0:
			u.statuses.voar -= 1

func battle_loop():
	var is_first_turn = true
	while true:
		current_state = State.BATTLE_PLAYER
		if not is_first_turn: draw_cards(2)
		is_first_turn = false
		
		process_turn_statuses()
		
		actions_left = max_actions
		redraws_left = 2 # <--- RESET DAS RECOMPRAS AQUI
		pending_card = null
		# button_end_turn = false #teste
		cards_container.show()
		update_focus(null)
		
		render_cards()
		msg_label.text = "Sua Vez! Jogue as cartas ou passe o turno."
		
		await turn_ended
		if current_state == State.END: break
		
		# --- FASE INIMIGA ---
		current_state = State.BATTLE_ENEMY
		button_end_turn.disabled = true
		cards_container.hide()
		pending_card = null
		
		var e_units = enemies.filter(func(e): return e.hp > 0)
		#e_units.sort_custom(func(a,b): return a.vel > b.vel)
		e_units.sort_custom(func(a,b): return a.get("vel", 0) > b.get("vel", 0))
		
		for e in e_units:
			if e.hp <= 0: continue
			
			# 1. INIMIGO ESCOLHE UMA CARTA ALEATÓRIA DO SEU ARSENAL
			var skill_name = e.get("skills", ["Ataque Básico"]).pick_random()
			var c_data = CARD_DB[skill_name]
			var has_reach = c_data.get("alcance", false)
			
			# 2. VERIFICA SE ESTÁ PRESO NA RETAGUARDA
			var in_retaguarda = has_retaguarda(e, enemies)
			if in_retaguarda and not has_reach and c_data.target != "SELF":
				msg_label.text = e.name + " tentou usar " + skill_name + ", mas não tem alcance da retaguarda!"
				await get_tree().create_timer(1.2).timeout
				continue
			
			# 3. FILTRA ALVOS VÁLIDOS PARA O ATAQUE
			var target = e
			if c_data.target != "SELF":
				var valid_targets = allies.filter(func(a): return a.hp > 0 and is_valid_target(a, allies, has_reach))
				if valid_targets.size() == 0:
					msg_label.text = e.name + " não tem alvos válidos para " + skill_name + "!"
					await get_tree().create_timer(1.2).timeout
					continue
				target = valid_targets.pick_random()
			
			# 4. ZOOM CINEMÁTICO E ANIMAÇÃO
			update_focus(e, target)
			cam_target_pos = target.get("pos")
			cam_target_zoom = Vector2(1.6, 1.6)
			await get_tree().create_timer(0.6).timeout
			
			e["anim_state"] = ANIM.SWING if c_data.target != "SELF" else ANIM.VICTORY
			audio_manager.play_sfx("res://attack.ogg")
			await get_tree().create_timer(0.2).timeout
			
			# 5. O INIMIGO EXECUTA AS PALAVRAS-CHAVE DA CARTA
			for effect in c_data.effects:
				if effect.tag == "DAMAGE":
					var dmg_type = effect.get("type", "IMPACTO")
					var is_piercing = effect.get("penetrante", false)
					var combo_hits = effect.get("combo", 0)
					
					if e.statuses.voar > 0 and not c_data.get("alcance", false):
						e.statuses.pouso = e.statuses.voar
						e.statuses.voar = 0
						msg_label.text = e.name + " pousou para atacar!"
					
					var targets_to_hit = [target]
					if combo_hits > 0:
						var target_group = enemies if target in enemies else allies
						var valid_combo_targets = target_group.filter(func(t): return t != target and t.hp > 0 and is_valid_target(t, target_group, c_data.get("alcance", false)))
						valid_combo_targets.shuffle()
						for i in range(min(combo_hits, valid_combo_targets.size())):
							targets_to_hit.append(valid_combo_targets[i])
							
					if c_data.target == "ENEMY_ROW":
						targets_to_hit = enemies.filter(func(e): return e.is_front == target.is_front and e.hp > 0)

					for t in targets_to_hit:
						# --- NOVA FÓRMULA DE DANO (ATRIBUTO + CARTA - DEFESA) ---
						var atk_stat = e.get("imp", 0) if dmg_type == "IMPACTO" else e.get("pod", 0)
						var def_stat = t.get("arm", 0) if dmg_type == "IMPACTO" else t.get("esc", 0)
						
						# (Ataque + Base da Carta) - Defesa do Alvo
						var raw_dmg = max(0, atk_stat + effect.get("base_dmg", 0) - def_stat)
						
						# Multiplicador do Type Chart (Pedra/Papel/Tesoura)
						var mult = TYPE_CHART[e.type][t.type]
						var final_dmg = float(raw_dmg) * mult
						
						# Redução Dinâmica dos Statuses de Buff (Armadura/Escudo Ativos)
						if dmg_type == "IMPACTO" and t.statuses.armadura > 0:
							final_dmg = final_dmg / (1.0 + (0.25 * t.statuses.armadura))
						elif dmg_type == "PODER" and t.statuses.escudo > 0:
							final_dmg = final_dmg / (1.0 + (0.25 * t.statuses.escudo))
						
						if t.get("protection", false) and not is_piercing:
							t["protection"] = false
							msg_label.text = t.name + " bloqueou o ataque!"
							audio_manager.play_sfx("res://shield.ogg")
						else:
							t.hp -= int(final_dmg)
							t["anim_state"] = ANIM.DAMAGE
							shake_strength = 25.0 * mult
							audio_manager.play_sfx("res://damage.ogg")
							
							#var p_text = " (Penetrante!)" if is_piercing and t.get("protection", false) else ""
							var p_text = " (Penetrante!)" if is_piercing and t.get("protection", false) else ""
							msg_label.text = "%s usou %s em %s%s!" % [e.name, skill_name, t.name, p_text]
							#msg_label.text = "%s usou %s em %s%s!" % [e.name, pending_card.name, t.name, p_text]
							await get_tree().create_timer(0.4).timeout
				
				elif effect.tag == "BUFF":
					var stat_name = effect.get("status")
					target.statuses[stat_name] = effect.get("duration", 1)
					msg_label.text = target.name + " usou " + skill_name + "!"
			
			# FIM DO TURNO DESTE INIMIGO
			await get_tree().create_timer(0.8).timeout
			e["anim_state"] = ANIM.IDLE
			if target.has("anim_state"): target["anim_state"] = ANIM.IDLE if target.hp > 0 else ANIM.DEAD
			
			check_deaths()
			render_entities()
			update_focus(null)
			
		if allies.filter(func(a): return a.hp > 0).size() == 0:
			finish_game("GAME OVER")
			break
		
		
	

		
func has_retaguarda(unit, group):
	# Se ele está na frente, nunca é retaguarda
	if unit.is_front: return false
	# Se está atrás, checa se existe alguém vivo na frente
	var front_alive = group.filter(func(u): return u.is_front and u.hp > 0)
	return front_alive.size() > 0
	
func is_valid_target(defender, defender_group, has_reach):
	var is_flying = defender.get("statuses", {}).get("voar", 0) > 0
	var in_retaguarda = has_retaguarda(defender, defender_group)
	
	# Se estiver voando ou na retaguarda, SÓ pode ser atacado se tiver alcance
	if (in_retaguarda or is_flying) and not has_reach:
		return false
	return true

func _on_target_clicked(target):
	if current_state != State.BATTLE_PLAYER or is_attacking: return
	
	# 1. INSPEÇÃO E BLOQUEIO DO ERRO 'NIL'
	if pending_card == null:
		show_inspect(target)
		return
		
	var c_data = CARD_DB[pending_card.name]
	
	# 2. REGRA DE ALVO (Retaguarda e Voo)
	var target_group = enemies if target in enemies else allies
	if not is_valid_target(target, target_group, c_data.get("alcance", false)):
		msg_label.text = target.name + " está protegido ou fora de alcance!"
		audio_manager.play_sfx("res://error.ogg")
		return
	
	# 3. VERIFICA CUSTOS
	if actions_left < c_data.cost_ap or initiative_points + c_data.init_mod < 0:
		msg_label.text = "Ações ou Iniciativa insuficientes!"
		audio_manager.play_sfx("res://error.ogg")
		return
	
	is_attacking = true
	var attacker = pending_card.owner
	
	# 4. ZOOM CINEMÁTICO
	update_focus(attacker, target, false)
	cam_target_pos = target.get("pos")
	cam_target_zoom = Vector2(1.6, 1.6)
	await get_tree().create_timer(0.5).timeout
	
	# 5. ANIMAÇÃO DE AÇÃO
	attacker["anim_state"] = ANIM.SWING if c_data.target != "ALLY" else ANIM.VICTORY
	audio_manager.play_sfx("res://attack.ogg")
	await get_tree().create_timer(0.3).timeout
	
	# 6. LEITOR DE PALAVRAS-CHAVE E CONSUMO DE AP/INICIATIVA
	actions_left -= c_data.cost_ap
	initiative_points = clamp(initiative_points + c_data.init_mod, 0, 10)
	
	for effect in c_data.effects:
		if effect.tag == "DAMAGE":
			var dmg_type = effect.get("type", "IMPACTO")
			var is_piercing = effect.get("penetrante", false)
			var combo_hits = effect.get("combo", 0)
			
			if attacker.statuses.voar > 0 and not c_data.get("alcance", false):
				attacker.statuses.pouso = attacker.statuses.voar
				attacker.statuses.voar = 0
				msg_label.text = attacker.name + " pousou para atacar!"
			
			var targets_to_hit = [target]
			if combo_hits > 0:
				# var target_group = enemies if target in enemies else allies
				var valid_combo_targets = target_group.filter(func(t): return t != target and t.hp > 0 and is_valid_target(t, target_group, c_data.get("alcance", false)))
				valid_combo_targets.shuffle()
				for i in range(min(combo_hits, valid_combo_targets.size())):
					targets_to_hit.append(valid_combo_targets[i])
					
			if c_data.target == "ENEMY_ROW":
				targets_to_hit = enemies.filter(func(e): return e.is_front == target.is_front and e.hp > 0)

			for t in targets_to_hit:
				# --- NOVA FÓRMULA DE DANO (ATRIBUTO + CARTA - DEFESA) ---
				var atk_stat = attacker.get("imp", 0) if dmg_type == "IMPACTO" else attacker.get("pod", 0)
				var def_stat = t.get("arm", 0) if dmg_type == "IMPACTO" else t.get("esc", 0)
				
				# (Ataque + Base da Carta) - Defesa do Alvo
				var raw_dmg = max(0, atk_stat + effect.get("base_dmg", 0) - def_stat)
				
				# Multiplicador do Type Chart (Pedra/Papel/Tesoura)
				var mult = TYPE_CHART[attacker.type][t.type]
				var final_dmg = float(raw_dmg) * mult
				
				# Redução Dinâmica dos Statuses de Buff (Armadura/Escudo Ativos)
				if dmg_type == "IMPACTO" and t.statuses.armadura > 0:
					final_dmg = final_dmg / (1.0 + (0.25 * t.statuses.armadura))
				elif dmg_type == "PODER" and t.statuses.escudo > 0:
					final_dmg = final_dmg / (1.0 + (0.25 * t.statuses.escudo))
				
				if t.get("protection", false) and not is_piercing:
					t["protection"] = false
					msg_label.text = t.name + " bloqueou o ataque!"
					audio_manager.play_sfx("res://shield.ogg")
				else:
					t.hp -= int(final_dmg)
					t["anim_state"] = ANIM.DAMAGE
					shake_strength = 25.0 * mult
					audio_manager.play_sfx("res://damage.ogg")
					
					var p_text = " (Penetrante!)" if is_piercing and t.get("protection", false) else ""
					msg_label.text = "%s usou %s em %s%s!" % [attacker.name, pending_card.name, t.name, p_text]
					await get_tree().create_timer(0.4).timeout
					
		# --- NOVAS TAGS DE STATUS ---
		elif effect.tag == "BUFF":
			var stat_name = effect.get("status") # armadura, escudo, voar
			target.statuses[stat_name] = effect.get("duration", 1)
			msg_label.text = target.name + " recebeu " + stat_name.capitalize() + "!"

	# 7. LIMPEZA DA MÃO
	# Encontra o nó da carta para animar antes de remover
	var card_node = null
	for c in cards_container.get_children():
		if c.get_meta("card_ref") == pending_card: # Precisamos adicionar essa meta no render_cards
			card_node = c; break
	
	if card_node:
		# A carta voa para o descarte, encolhe e desaparece
		var tween = create_tween().set_parallel(true)
		tween.tween_property(card_node, "global_position", discard_pos, 0.6).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN)
		tween.tween_property(card_node, "scale", Vector2(0.1, 0.1), 0.6)
		tween.tween_property(card_node, "modulate:a", 0.0, 0.6)
		await tween.finished
	
	hand.erase(pending_card)
	discard_pile.append(pending_card)
	pending_card = null
	render_cards()
	
	# 8. RETORNO À POSIÇÃO NORMAL
	await get_tree().create_timer(0.6).timeout
	attacker["anim_state"] = ANIM.IDLE
	if target.has("anim_state"): target["anim_state"] = ANIM.IDLE if target.hp > 0 else ANIM.DEAD
	
	render_cards()
	check_deaths()
	render_entities()
	
	cam_target_pos = Vector2(screen_w/2.0, screen_h/2.0)
	cam_target_zoom = Vector2(1.0, 1.0)
	await get_tree().create_timer(0.4).timeout
	
	update_focus(null)
	is_attacking = false
	
	if get_live_enemies().size() == 0:
		finish_game("VENCEU")
		turn_ended.emit()
		
# ==========================================
# 9. SISTEMAS FINAIS
# ==========================================
func check_deaths():
	for a in allies:
		if a.hp <= 0 and not a.has("is_dead"):
			a["is_dead"] = true
			purge_dead_ally_cards(a)

func get_live_enemies():
	return enemies.filter(func(e): return e.hp > 0)

func finish_game(txt):
	current_state = State.END
	msg_label.text = ""
	button_end_turn.hide()
	cards_container.hide()
	init_label.hide()
	ap_label.hide()
	
	var final = Label.new()
	final.text = txt
	final.set_anchors_preset(Control.PRESET_CENTER)
	final.add_theme_font_size_override("font_size", 80)
	if txt == "VENCEU": final.add_theme_color_override("font_color", Color.GREEN)
	else: final.add_theme_color_override("font_color", Color.RED)
	ui_layer.add_child(final)
