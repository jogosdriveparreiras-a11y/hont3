extends Node

# Toca um som. Se o arquivo não existir, imprime no console e segue o jogo.
func play_sfx(path: String):
	if ResourceLoader.exists(path):
		var sfx = load(path)
		if sfx is AudioStream:
			var player = AudioStreamPlayer.new()
			player.stream = sfx
			add_child(player)
			player.play()
			
			# Destrói o nó de áudio assim que a música terminar (evita vazamento de memória)
			player.finished.connect(func(): player.queue_free())
	else:
		print("SFX não encontrado (pode ignorar): ", path)
